python /Users/jlmart88/Desktop/6.S912/pythonbot/Player_copy.py "$@"
