#!/bin/sh
export DYLD_LIBRARY_PATH=/Users/jlmart88/Downloads/pbots_calc-master-2/pbots_calc-master/export/darwin/lib:$LD_LIBRARY_PATH
python /Users/jlmart88/Downloads/pbots_calc-master-2/pbots_calc-master/python/calculator.py $@