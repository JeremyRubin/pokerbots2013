from Actions import *
from Cards import *


class Betting():

    def __init__(self):
        pass
